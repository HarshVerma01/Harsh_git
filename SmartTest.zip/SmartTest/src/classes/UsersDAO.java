package classes;
import org.hibernate.*;
import java.util.*;

public class UsersDAO {
	public static boolean validate(beans.UsersBean bean) {
		boolean status = false;
		Session session = com.Users.getUserSessionFactory().openSession();
		session.beginTransaction();
		String email = bean.getEmail();
		String password = bean.getPassword();		
		String hql = "SELECT COUNT(*) FROM USERS WHERE EMAIL = :email AND PASSWORD = :password";
		Query query = session.createQuery(hql);
		List result = query.list();
		if(result.size()>0) status = true;
		return status;
	}
}
