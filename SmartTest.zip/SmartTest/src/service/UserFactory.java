package service;

import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class UserFactory {
	public SessionFactory userSessionFactory() {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		//StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties());
		//SessionFactory sessionFactory = cfg.buildSessionFactory(builder.build());
		return sessionFactory;
	}
}
