package com;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class Users {
	public static SessionFactory getUserSessionFactory() {
		Configuration cfg = new Configuration().configure("service.hibernate.cfg.xml");
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		return sessionFactory;
	}
}
